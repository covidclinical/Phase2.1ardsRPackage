
#' Obfuscates small counts in result data for sites where IRBs require such for the ards project
#'
#' @keywords 4CE
#' @export

smallCountObfuscation <- function() {
	#TODO: implement obfuscation of small counts -- helper code coming soon
}

