
#' Validates the results of the analytic workflow for the ards project
#'
#' @keywords 4CE
#' @export

validateAnalysis <- function() {
	#TODO: implement validation
}

